function randomcolor() {
    let result = ""
    const hex = "0123456789ABCDEF"
    const charLength = 6
    let counter = 0
    while (counter < charLength) {
        result += hex.charAt(Math.floor(Math.random() * 16))
        counter += 1
    }
    document.body.style.background = "#" + result
    document.getElementById("Text").textContent = "#" + result
}