var ul = document.getElementById("ul");
var temp_input = document.getElementById("input")
var btn = document.getElementById("btn");

function add_func(x) {
    const value = x || temp_input.value.trim()
    if (value.length) {
        var li = document.createElement("li");
        li.innerHTML = `<span>${value}</span> <button class="del_btn">Delete</button>`;
        ul.appendChild(li)
        temp_input.value = ""
        li.querySelector(".del_btn").addEventListener("click", () => {
            ul.removeChild(li)
            save()
        })
        save()
    }
}

btn.addEventListener("click", () => {
    add_func()
}) 

function save() {
    const tasks = []
    ul.querySelectorAll("li span").forEach(task => {
        tasks.push(task.textContent)
    });

    localStorage.setItem("key", JSON.stringify(tasks))
}

function load() {
    keys = JSON.parse(localStorage.getItem("key"))
    if (keys) {
        keys.forEach(key => {
            add_func(key)
        })
    }
}

load()

