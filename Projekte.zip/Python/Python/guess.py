import random
import time

tries = 0

def rand_num(x, y):
    try:
        result = random.randint(int(x), int(y))
        guess = input("Guess a number: ")
        if int(guess) == int(result):
            print("The number was ",str(result))
            print("You have guessed ",str(guess))
            print("Congrats!")
        else:
            print("The number was ", str(result))
            print("You have guessed ", str(guess))
            print("You havent guessed Correctly!")
    except:
        print("Invalid!")

while True:
    print("Do you want to generate a random number?")
    answer = input("Y/N : ")
    if answer == "Y":
        first_num = input("First Number: ")
        second_num = input("Second Number: ")
        rand_num(first_num, second_num)
        tries += 1
        if tries == 1:
            print("You have guessed ", str(tries), " time!")
        else:
            print("You have guessed ", str(tries), " times!")
    elif answer == "N":
        print("See you! ")
        time.sleep(1)
        exit()
    else:
        print("Invalid!")


