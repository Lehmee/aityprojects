name = input()

if name == "Luca":
    print(name)
    
elif name == "aity":
    print(name)

elif name == "bekb":
    print(name)
    
elif name == "gibb":
    print(name)
    
    
match name:
    case "Luca":
        print(name)
    case "aity":
        print(name)
    case "bekb":
        print(name)
    case "gibb":
        print(name)
    case _:
        print(name)
    