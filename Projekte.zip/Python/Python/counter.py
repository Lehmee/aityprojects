import time

def count_up(x):
    if int(x) < 0:
        print("Invalid")
    else:
        try:
            c = 0
            while int(x) != c:
                c += 1
                print(c)
                time.sleep(0.1)
            if int(x) == c:
                print("Done!")
        except:
            print("Invalid!")
        
def count_down(x):
    if int(x) < 0:
        print("Invalid")
    else:
        try:
            c = 0
            while int(x) != c:
                x -= 1
                print(x)
                time.sleep(0.1)
            if int(x) == c:
                print("Done!")
        except:
            print("Invalid!")

while True:
    print(20*"-")
    print("Number Counter!") 
    print(20*"-")
        
    num = input("Number: ")
    
    if num == "exit":
        exit()

    select = input("Do you want to Count down [Down] or Up [Up]!")
    if select == "Down":
        count_down(int(num))
    elif select == "Up":
        count_up(int(num))
    else:
        print("Invalid!")
        