document.getElementById("btn").addEventListener("click", Start)

var minutes = 4
var seconds = 59

active = false

function Start() {
    if (active == true) {
        active = false
        document.getElementById("btn").textContent = "Start"
        if (minutes == 0 && seconds == 0) {
            document.getElementById("btn").textContent = "Neu"
        }
    }
    else if (active == false) {
        active = true
        if (document.getElementById("btn").textContent == "Neu") {
            document.getElementById("Time").textContent = "5:00"
            minutes = 4
            seconds = 59
        }
        document.getElementById("btn").textContent = "Stop"
    }
    if (active == true) {
        start_stop = true
        start_stop = setInterval(function() {
            if (minutes >= 0) {
                if (seconds >= 0) {
                    if (seconds == 0) {
                        trimed_text = "0" + seconds
                        document.getElementById("Time").textContent = minutes + ":" + trimed_text.trim()
                        if (minutes != 0) {
                            seconds = 59
                            minutes -= 1
                        }
                        console.log(minutes, seconds)
                    }
                    else if (seconds.toString().length == 1) {
                        trimed_text = "0" + seconds
                        document.getElementById("Time").textContent = minutes + ":" + trimed_text.trim()
                        seconds -= 1
                    }
                    else {
                        document.getElementById("Time").textContent = minutes + ":" + seconds
                        seconds -= 1 
                    }
                }
            }
        },10)
    }
    else if (active == false) {
        clearInterval(start_stop)
    }
}